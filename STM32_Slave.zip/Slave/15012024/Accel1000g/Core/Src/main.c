#include "main.h"
#include "stdbool.h"
#include "MPC3564.h"
#include "func.h"
#include "FM25V05.h"
#include "Lora.h"
#include "string.h"
#include "stdio.h"

#define DIO0_Pin GPIO_PIN_10
#define DIO0_GPIO_Port GPIOB
#define RESET_Pin GPIO_PIN_3
#define RESET_GPIO_Port GPIOA
#define NSS_Pin GPIO_PIN_12
#define NSS_GPIO_Port GPIOA

SPI_HandleTypeDef hspi2;
UART_HandleTypeDef huart1;

LoRa myLoRa;

volatile uint8_t Lora_read = 0;
volatile uint8_t TXDone = 0;

uint8_t read_data[6];
char uart_buf[32];
float Blast_Time = 0.0f;

#define RECEIVE_MODE 0
#define TRANSMIT_MODE 1
uint8_t lora_mode = RECEIVE_MODE;

float ascii_to_float(uint8_t *str);

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
    if (GPIO_Pin == myLoRa.DIO0_pin) {
        if (lora_mode == RECEIVE_MODE) {
            Lora_read = 1;
        } else if (lora_mode == TRANSMIT_MODE) {
            TXDone = 1;
        }
    }
}

float ascii_to_float(uint8_t *str) {
    float result = 0.0f;
    int integer_part = 0;
    float fraction_part = 0.0f;
    float fraction_divisor = 1.0f;
    int is_fraction = 0;

    while (*str) {
        if (*str == '.' || *str == ':') {
            is_fraction = 1;
            str++;
            continue;
        }

        if (*str >= '0' && *str <= '9') {
            if (!is_fraction) {
                integer_part = integer_part * 10 + (*str - '0');
            } else {
                fraction_part = fraction_part * 10 + (*str - '0');
                fraction_divisor *= 10.0f;
            }
        } else {
            break;
        }
        str++;
    }
    result = integer_part + (fraction_part / fraction_divisor);
    return result;
}

int main(void) {
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_SPI2_Init();
    MX_USART1_UART_Init();

    myLoRa = newLoRa();
    myLoRa.CS_port = NSS_GPIO_Port;
    myLoRa.CS_pin = NSS_Pin;
    myLoRa.reset_port = RESET_GPIO_Port;
    myLoRa.reset_pin = RESET_Pin;
    myLoRa.DIO0_port = DIO0_GPIO_Port;
    myLoRa.DIO0_pin = DIO0_Pin;
    myLoRa.hSPIx = &hspi2;

    myLoRa.frequency = 433;
    myLoRa.spredingFactor = SF_7;
    myLoRa.bandWidth = BW_250KHz;
    myLoRa.crcRate = CR_4_5;
    myLoRa.power = POWER_20db;
    myLoRa.overCurrentProtection = 120;
    myLoRa.preamble = 16;

    LoRa_reset(&myLoRa);
    if (LoRa_init(&myLoRa) != LORA_OK) {
        HAL_UART_Transmit(&huart1, (uint8_t *)"LoRa init failed\n", 17, 100);
        while (1);
    }

    HAL_UART_Transmit(&huart1, (uint8_t *)"LoRa Receiver ready\n", 21, 100);

    LoRa_startReceiving(&myLoRa);
    lora_mode = RECEIVE_MODE;

    while (1) {
   if (Lora_read) {
    Lora_read = 0;

    memset(read_data, 0, sizeof(read_data));
    LoRa_receive(&myLoRa, read_data, 6);

    HAL_UART_Transmit(&huart1, (uint8_t *)"RX: ", 4, 20);
    HAL_UART_Transmit(&huart1, read_data, 6, 20);
    HAL_UART_Transmit(&huart1, (uint8_t *)"\n", 1, 20);

    lora_mode = TRANSMIT_MODE;
    LoRa_gotoMode(&myLoRa, STDBY_MODE);

    HAL_Delay(150);  // increased delay to let Pi switch RX

    HAL_UART_Transmit(&huart1, (uint8_t *)"TX: ACK\n", 8, 20);
    LoRa_transmit(&myLoRa, read_data, 6, 100);

    while (!TXDone) HAL_Delay(1);
    TXDone = 0;

    lora_mode = RECEIVE_MODE;
    LoRa_startReceiving(&myLoRa);
}
}
}